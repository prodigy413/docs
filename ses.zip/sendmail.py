import smtplib
import email.utils
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

receiver_list = ["xxxxxxxxxx@xxxxxx.co.jp"]

SENDER = "xxxxxx@xxxxx.com"
SENDERNAME = "test"

USERNAME_SMTP = "xxxxxxxx"
PASSWORD_SMTP = "xxxxxx"

HOST = "email-smtp.ap-northeast-1.amazonaws.com"
PORT = 587

for RECEIVER in receiver_list:
    msg = MIMEMultipart("alternative")
    msg["Subject"] = "test"
    msg["From"] = email.utils.formataddr((SENDERNAME, SENDER))
    msg["To"] = RECEIVER

    server = smtplib.SMTP(HOST, PORT)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login(USERNAME_SMTP, PASSWORD_SMTP)
    server.sendmail(SENDER, RECEIVER, msg.as_string())
    server.close()
